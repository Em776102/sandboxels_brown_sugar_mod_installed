elements.brown_suger = {
    color: "#B87333",
    behavior: behaviors.POWDER,
    category: "powders",
    state: "solid",
    density: 1150,
    tempHigh: 100,
    stateHigh: "caramel"
};

elements.brown_suger.reactions = elements.brown_suger.reactions || {};
elements.sugar.reactions = elements.sugar.reactions || {};
elements.molasses.reactions = elements.molasses.reactions || {};

elements.brown_suger.reactions.ketchup = {
    elem1: elements.bbq_sauce,
    result: "Barbeque Sauce"
};


elements.sugar.reactions.molasses = {
    elem2: elements.molasses,
    result: "brown_suger"
};


elements.molasses.reactions.sugar = {
    elem2: elements.sugar,
    result: "brown_suger"
};
